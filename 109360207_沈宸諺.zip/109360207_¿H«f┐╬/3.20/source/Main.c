#include <stdio.h>
#include <stdlib.h>

int main() {
	float work, rate, salary, bonus, plus;
	work = 0;
	while (work != -1) {

		printf("Enter # of hours worked (-1 to end): ");
		scanf_s("%f", &work);
		printf("Enter hourly rate of the worker($00.00):");
		scanf_s("%f", &rate);
		if (work <= 40)
		{
			salary = work * rate;
		}
		else if (work > 40)
		{
			bonus = work - 40;
			plus = bonus * 1.5*rate;
			salary = (40*rate) + plus;
		}

		printf("Salary is $ %f\n", salary);
	}

	system("pause");
	return 0;
}