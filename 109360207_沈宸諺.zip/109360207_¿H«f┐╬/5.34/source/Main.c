#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include<stdio.h>
int function(int x, int y);
int main()
{
	int a, b;
	printf("��J��ƭ�\n");
	scanf("%d%d", &a, &b);
	printf("answer is %d", function(a, b));
}
int function(int x, int y)
{
	int c;
	int d;
	d = x;
	for (c = 1; c < y; c++)
	{ 
		x = d * x;

	}
	return x;
}