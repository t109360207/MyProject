#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int fun(intx, inty);

int main()
{
	int aa, bb, cc;

	printf("��J��ƭ�\n");
	scanf("%d %d", &aa, &bb);


	printf("LCM of aa amd bb is %d", fun(aa, bb));


}
int fun(int x, int y)
{

	int i = 2;
	int ans = 1;
	if (x == 1 || y == 1)
	{
		return x * y;
	}
	else if (x >= i && y >= i)
	{

		while (x >= i && y >= i)
		{

			while (x%i == 0 && y%i == 0)
			{
				ans = ans * i;
				x /= i;
				y /= i;
			}
			i++;
		}
		return ans * x*y;
	}
}