#include <stdio.h>
#include <stdlib.h>

int wide, high, hh, ww, i, j, k;

int main() {
	printf("Enter the height :");
	scanf_s("%d", &high);
	printf("Enter the wide :");
	scanf_s("%d", &wide);
	for (i = 1 ; i <= wide ; i++)
	{
		printf("*");
	}
	printf("\n");
	for (j = 1 ; j <= high-2 ; j++)
	{
		printf("*");
		for (k = 1 ; k <= wide-2 ; k++)
		{
			printf(" ");
		}
		printf("*\n");
	}
	for (ww = 1; ww <= wide; ww++)
	{
		printf("*");
	}
	system("pause");
	return 0;
}
