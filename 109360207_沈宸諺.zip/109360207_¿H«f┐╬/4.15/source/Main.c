#include <stdio.h>
#include <stdlib.h>

float  principal, interest, rate, i, j, k, year;

int main()
{
	principal = 5000;

	for (i = 10; i <= 12; i += 0.5)
	{
		for (year = 1; year <= 15; year++)
		{
			principal = principal + principal / 100 * i;
		}
		
		printf("����:5000 , �~�Q�v : %f %%, 15�~�᥻���[�Q���� : %f\n", i, principal);
		
		principal = 5000;
	}
	system("pause");
	return 0;
}