#include <stdio.h>
#include <stdlib.h>

int main() 
{       
	float sale, salary, plus ;
	sale = 0;
	while (sale != -1) {
						printf("Enter sales in dollars(-1 to end):");
						scanf_s("%f", &sale);
						if (sale == -1){
										break;
										}
						salary = sale + 200 + (sale*0.09);
						printf("salary is: %f\n", salary);
						}
						system("pause");
						return 0;
}
