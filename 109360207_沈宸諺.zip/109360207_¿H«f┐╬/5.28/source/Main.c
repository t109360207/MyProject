#include <stdio.h>
#include <stdlib.h>
#include <string.h>



void main()
{
	char in;
	char out;
	printf("Enter a Alphbet�G");
	scanf_s("%c", &in);
	if (in > 122 || in < 65)
	{
		printf("Enter am error alphabet");
		system("pause");
	}
	if (in <= 90)
	{
		out = in + 32;
	}
	else
	{
		out = in - 32;
	}
	
	printf("           %c\n\n",out);
	system("pause");
	return 0;
}

