#include <stdio.h>
#include <stdlib.h>

int main() {
	float principal, rate, days, charge, interest;
	principal = 0;
	while (principal != -1) {
		printf("Enter loan principal (-1 to end):");
		scanf_s("%f", &principal);
		if (principal == -1){
			break;
		}
		printf("Enter interest rate:");
		scanf_s("%f", &rate);
		printf("Enter term of the loan in days:");
		scanf_s("%f", &days);
		charge = (principal*rate*days) / 365 ;
		printf("The interest charge is:%f\n",charge);
		
	}
	system("pause");
	return 0;
}