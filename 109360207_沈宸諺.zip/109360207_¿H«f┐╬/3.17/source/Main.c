#include<stdio.h>
#include<stdlib.h>

int main() {
				float account, balance, charge, credit, limit, sum;
				twice:printf("enter account number (-1 to end):");
				scanf_s("%f", &account);
				while (account != -1) {
										printf("enter begining balance:");
										scanf_s("%f", &balance);
										printf("enter total charges:");
										scanf_s("%f", &charge);
										printf("enter total credits:");
										scanf_s("%f", &credit);
										printf("enter credit limit:");
										scanf_s("%f", &limit);
										sum = balance + charge - credit;
										if (sum >= limit) {
															printf("account:\t%f\n", account);
															printf("credit limit:\t%f\n", limit);
															printf("balance:\t%f\n", balance);
															printf("credit limit exceeded\n");
														}
										goto twice;
										}
				system("pause");
				return 0;
			}