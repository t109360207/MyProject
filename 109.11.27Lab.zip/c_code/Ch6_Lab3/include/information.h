#include <stdio.h>
#include <stdlib.h>
typedef struct _student {

	char num[7];
	char class[20];
	char name[20];
	int score[3];
}student;