#include <stdio.h>
#include "information.h"

void sub(student *p);
int main()

{
	int i;
	student stud[3] = { {"970101","�|�l�@��","���p��",61,71,81},
	{"970101","�|�l�@��","������",92,82,72},
	{"970101","�|�l�@��","�i�j��",73,63,83} };
	student *ps;
	printf("\n");
		ps = stud;
	printf("========================================================\n");
	printf("  �Ǹ�  �Z��\t�m�W\t   ���   �^��   �ƾ�\n");
	printf("========================================================\n");
	for (i = 0; i < 3; i++) {
		printf("%6s %-10s %-8s %4d %d4 %4d\n", (ps + i)->num, (ps + i)->class,
			(ps + i)->name, (ps + i)->score[0], (ps + i)->score[1], (ps + i)->score[2]);
	}
	printf("\t�I�s�禡�e\n\n");
	sub(ps);
	printf("\n�I�s�禡�e\n\n");
	for (i = 0; i < 3; i++)
	{
		printf("%6s %-10s %-8s %4d %d4 %4d\n", (ps + i)->num, (ps + i)->class,
			(ps + i)->name, (ps + i)->score[0], (ps + i)->score[1], (ps + i)->score[2]);
	}
	printf("\n");
	system("pause");
	return 0;
}
void sub(student *p)
{
	for (int i = 0; i < 3; i++)
	{
		(p + i)->score[0] += 10;
		(p + i)->score[1] += 10;
		(p + i)->score[2] += 10;
	}
}


