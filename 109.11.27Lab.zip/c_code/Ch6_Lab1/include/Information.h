#include <stdio.h>

typedef struct _sPerson {

	char name[8];
	int gender;
	int age;
}Person;