#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	printf("*********	   ***		   *          *    \n");
	printf("*       *	 *     *	  ***	     * *   \n");
	printf("*       *	*       *	 *****      *   *  \n");
	printf("*       *	*       *	   *       *     * \n");
	printf("*       *	*       *	   *      *       *\n");
	printf("*       *	*       *	   *       *     * \n");
	printf("*       *	*       *	   *        *   *  \n");
	printf("*       *	 *     *	   *         * *   \n");
	printf("*********	   ***		   *          *    \n");
	                 
	system("pause");
	return  0;
}