#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	printf("PPPPPPPPP  \n");
	printf("    P   P  \n");
	printf("    P   P  \n");
	printf("    P   P  \n");
	printf("     P P   \n");
	printf("           \n");
	printf("   JJ      \n");
	printf(" J         \n");
	printf("J          \n");
	printf(" J         \n");
	printf("   JJJJJJ  \n");
	printf("           \n");
	printf("DDDDDDDDDDD\n");
	printf("D         D\n");
	printf("D         D\n");
	printf(" D       D \n");
	printf("   DDDDDD  \n");

	system("pause");
	return 0;
}